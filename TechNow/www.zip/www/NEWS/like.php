<?php
  
    $m = new MongoClient();
   $db = $m->project;
   
   $collection = $db->news;
   $news_id = new MongoId($_GET['id']);
   $arr = array("_id"=>$news_id);
   $rep=array('$inc' =>array("likes"=>1));
   $check = $collection->findOne($arr);

   $newsarray = $check['newsarray'];

   $uid = $_GET['uid'];
   if(in_array($uid, $newsarray))
    {
      header('Location:news.php');
    }
    else
    {
      $collection->update($arr,$rep);
      $inslike = array('$addToSet'=>array("newsarray"=>$uid));
      $collection->update($arr,$inslike);
      header('Location:news.php');
    }

   
   
?>