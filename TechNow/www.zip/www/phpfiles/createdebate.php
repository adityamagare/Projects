<?php

$m = new MongoClient();
$db = $m->project;
$coll = $db->debatetopic;
$gridfs = $db->getGridFS();

echo $_FILES["pic1"]["name"];
echo $_FILES["pic2"]["name"];

	if($_POST["tname"]){
		$num = 0;
		$A = $_POST['A'];
		$B = $_POST['B'];
		$d=$_POST['date'];
		$m=$_POST['month'];
		$y=$_POST['year'];
if(empty($_FILES["pic1"]["name"]) && empty($_FILES["pic2"]["name"]))
{

	$document = array("tname"=>$_POST["tname"],							
							"createdby"=>$_GET["createdby"],
							"upvote"=>$num,
							"upvotearray"=>[],
							"downvote"=>$num,
							"downvotearray"=>[],
							"filetype1"=>"",
							"imageid1"=>"",
							"filetype2"=>"",
							"imageid2"=>"",
							"A"=>$A,
							"B"=>$B,
							"date"=>$d,
							"month"=>$m,
							"year"=>$y);
}
else
{
	$filetype1 = $_FILES["pic1"]["type"];
	$imageid1 = $gridfs->storeUpload('pic1');
	$filetype2 = $_FILES["pic2"]["type"];
	$imageid2 = $gridfs->storeUpload('pic2');
	$document = array("tname"=>$_POST["tname"],							
							"createdby"=>$_GET["createdby"],
							"upvote"=>$num,
							"upvotearray"=>[],
							"downvote"=>$num,
							"downvotearray"=>[],
							"filetype1"=>$filetype1,
							"imageid1"=>$imageid1,
							"filetype2"=>$filetype2,
							"imageid2"=>$imageid2,
							"A"=>$A,
							"B"=>$B,
							"date"=>$d,
							"month"=>$m,
							"year"=>$y);
}

		
		$coll->insert($document);
		header("Location:/d.php");
		echo "success";
}
	
	
?>