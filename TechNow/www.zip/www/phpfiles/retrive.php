<?php
	
	
	function comment()
	{
		$m1 = new MongoClient();
		$db1 = $m1->project;
		$coll1 = $db1->discussion;

		switch ($_POST['s']) 
		{
			case 'affirmative':
				echo "affirmative";
				$des = $_POST['aff'];
				$side = "aff";
				break;
			case 'negative':
				echo "negative";
				$des = $_POST['neg'];
				$side = "neg";
				break;
			default:
				echo '<script type="text/javascript">alert("write something..........");</script>';
				break;
		}
		$agree = 0;
		$disagree =0;
		$insert = array("id"=>$_GET['id'],
							"comment"=>$des,
							"side"=>$side,"agree"=>$agree,"disagree"=>$disagree);
	
		$coll1->insert($insert);
	//	$coll1->close();
	}
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		comment();
	} 

?>
<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript">
		function showHint(x,b)
		{
			//var x =document.getElementById("first").name;
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	           		//location.reload();
	            }
	        };
	        xmlhttp.open("GET", "/phpfiles/likedislike.php?id=" + x + "&button=" + b, true);
	        xmlhttp.send();
		}
	</script>
	<title><?php echo $_GET['title']; ?></title>
</head>
<body>
	<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
	
		<p>
			<input type="text" name="aff" />
			<input type="submit" name="s" value="affirmative" />
		</p>
		</br>
		<p>
			<input type="text" name="neg" />
			<input type="submit" name="s" value="negative" />
		</p>
	</form>


	<?php
		
		
$m2 = new MongoClient();
        $db2 = $m2->project;
        $coll2 = $db2->discussion;

        $d1 = array("id"=>$_GET['id'],"side"=>"aff");
        $d2 = array("id"=>$_GET['id'],"side"=>"neg");
        $cursor1 = $coll2->find($d1);
        $cursor2 = $coll2->find($d2);

        $d3 = array("id"=>$_GET['id']);
        $cursor = $coll2->find($d3);
        $data = "<table border='1'>";
        foreach ($cursor as $document) 
        {
            $f=$document["_id"];
            $data .= "<tr>";
            if($document["side"]=="aff")
            {
                $a = "agree";
                $da = "disagree";
                $data .= "<td>AFF: ".$document["comment"]."</td><td>".$document['agree']."</td><td>".$document['disagree']."</td>";
                $data .='<td><button onClick= showHint("' . $f.'","'.$a.'");>Like</button></td>';
                $data .='<td><button onClick= showHint("' . $f.'","'.$da.'");>Dislike</button></td>';   
            }
            else if($document["side"]=="neg")
            {
                $a = "agree";
                $da = "disagree";
                $data .= "<td>NEG: ".$document["comment"]."</td><td>".$document['agree']."</td><td>".$document['disagree']."</td>";
                $data .='<td><button onClick= showHint("' . $f.'","'.$a.'");>Like</button></td>';
                $data .='<td><button onClick= showHint("' . $f.'","'.$da.'");>Dislike</button></td>';   
            }   
            $data .= "</tr>";
        }
        $data .="</table>";
        echo $data;




		//------------------------------------------------------------------------------------------------------------
/*
		$data = "<table border=1><tr><td><table>";
		foreach ($cursor1 as $document1) 
		{
			$f=$document1["_id"];
			$a = "agree";
			$da = "disagree";
			$data .= "<tr>";
			$data .= "<td>AFF: ".$document1["comment"]."</td><td>".$document1['agree']."</td><td>".$document1['disagree']."</td>";
			$data .='<td><button onClick= showHint("' . $f.'","'.$a.'");>Like</button></td>';
			$data .='<td><button onClick= showHint("' . $f.'","'.$da.'");>Dislike</button></td>';
			$data .= "</tr>";
		}
		$data .= "</table></td><td><table>";
		foreach ($cursor2 as $document2) 
		{
			$f=$document2["_id"];
			$a = "agree";
			$da = "disagree";
			$data .= "<tr>";
			$data .= "<td>NEG: ".$document2["comment"]."</td><td>".$document2['agree']."</td><td>".$document2['disagree']."</td>";
			$data .='<td><button onClick= showHint("' . $f.'","'.$a.'");>Like</button></td>';
			$data .='<td><button onClick= showHint("' . $f.'","'.$da.'");>Dislike</button></td>';
			$data .= "</tr>";
		}
		$data .= "</table></td></tr></table>";

		echo $data;

	
	*/	
	?>	

	

</body>
</html>