<?php
	$m = new MongoClient();
	$d = $m->project;
	// ----------------------------------------for like and dislike
	
	//-----------------------------------------for adding to user account
	$coll1 = $d->registration;
	$uid = new MongoID("58e0e2450f6a6c0421000029");
	$first1 = array("_id"=>$uid);
	/*if($button=="agree")
	{
		$second1 = array("$addToSet"=>array("likes"=>$uid));
	}
	else
	{
		$second1 = array("$addToSet"=>array("dislikes"=>$uid));
	}*/
	$second1 = array('$addToSet'=>array("likes"=>$uid));
	$coll1->update($first1,$second1);

	
?>
