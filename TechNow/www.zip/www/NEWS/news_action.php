<?php 
session_start();
$HEADING=$_POST['heading'];
$CATEGORY=$_POST['category'];
$DETAILS=$_POST['details'];
$m = new MongoClient();
$db = $m->project;
$collection = $db->news;
$gridfs = $db->getGridFS();
$collection1=$db->likes;

if(empty($_FILES["pic"]["name"]))
{
  $document = array(
      "heading" =>$HEADING , 
      "category" =>$CATEGORY , 
       "details" =>$DETAILS,
       "author" =>$_SESSION['logdata']['username'],
       "uploaded_on"=>new MongoDate(),
       "total_comment" =>0,
       "newsarray" => [],
       "likes"=> 0,
       "reportarray" => [],
       "report" =>0,
       "filetype"=>"",
        "imageid"=>""
   );
}
else
{
  $filetype = $_FILES["pic"]["type"];
  $imageid = $gridfs->storeUpload('pic');
  $document = array(
      "heading" =>$HEADING , 
      "category" =>$CATEGORY , 
       "details" =>$DETAILS,
       "author" =>$_SESSION['logdata']['username'],
       "uploaded_on"=>new MongoDate(),
       "total_comment" =>0,
       "newsarray" => [],
       "likes"=> 0,
       "reportarray" => [],
       "report" =>0,
       "filetype"=>$filetype,
        "imageid"=>$imageid
   );
}
   

  
	
   $collection ->insert($document);
   $collection3=$db->register;
   $Author=$_SESSION['user'];
   $collection3->update(array("username"=>$Author),array('$inc' =>array("total_post"=>1)));


   header('Location:news.php');

?>