<?php


   
if(isset($_POST['username'])&& isset($_POST['password']))
{
	session_start();
	$doc=array("username"=>$_POST['username'],"password"=>$_POST['password']);
	$m = new MongoClient();
   
	
   // select a database
   $db = $m->project;
   $admin="admin";
   $collection = $db->registration;
	$query=$collection->findone($doc);
	$_SESSION['id'] = $query['_id'];
	if(!empty($query) && $query['password']==$admin )
	{
		echo "Logged In";
		$_SESSION['user']=$_POST['username'];
		header("Location: admin.php");

	}
	else if(!empty($query))
	{
		echo "Logged In";
		$_SESSION['user']=$_POST['username'];
		header("Location: home.php");

	}
	else
		echo "wrong email and password";
}
?>