<?php
	session_start();
	unset($_SESSION['logdata']);
	session_destroy();
	header("Location:/intro.php");
?>