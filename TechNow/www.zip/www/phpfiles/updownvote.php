<?php
	$m = new MongoClient();
	$d = $m->project;
	// ----------------------------------------for like and dislike
	$coll = $d->debatetopic;
	$mongoid = new MongoID($_GET['id']);
	$button = $_GET['button'];
	$first = array("_id"=>$mongoid);
	$second = array('$inc'=>array($button=>1));
	$coll->update($first,$second);
	$uid = $_GET['uid'];
	if($button=="upvote")
	{
		$second1 = array('$addToSet'=>array("upvotearray"=>$uid));
	}
	else
	{
		$second1 = array('$addToSet'=>array("downvotearray"=>$uid));
	}
	$coll->update($first,$second1);
	$m->close();
	
?>
