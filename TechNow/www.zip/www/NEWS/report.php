<?php
  
    $m = new MongoClient();
   $db = $m->project;

   $collection = $db->news;
   $news_id = new MongoId($_GET['id']);
   $arr = array("_id"=>$news_id);
   $rep=array('$inc' =>array("report"=>1));
   $check = $collection->findOne($arr);

   $reportarray = $check['reportarray'];

   $uid = $_GET['uid'];
   if(in_array($uid, $reportarray))
    {
      header('Location:news.php');
    }
    else
    {

      $collection->update($arr,$rep);
      $inslike = array('$addToSet'=>array("reportarray"=>$uid));
      $collection->update($arr,$inslike);
      header('Location:news.php');
    }

   
   
?>