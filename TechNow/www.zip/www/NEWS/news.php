	<?php
    session_start();
?>


<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TechNow</title>
    <!-- web-fonts -->
    <link href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,500' rel='stylesheet' type='text/css'>
   <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <!-- font-awesome -->
    <link href="fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/news.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="js/classie.js"></script>

  

<style>
body {
    font-family: 'Roboto', serif;
    font-size: 13px;
    line-height: 21px;
    color: #67706E;
    background: #ffffff;
}
.plus_sign{
    float: right ;
    position: fixed;
        bottom: 0;
        right: 0;
}
.logout_sign{
    float: right;
    position: absolute;
    top: 0;
    right : 0;

}
#next
{
    color:red;
    font-size: 200%;
}
.report_bt, .like_bt
{
    display: inline-block;
}
#comment_bt
{
    display: inline-block;
}
</style>
</head>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
<body>
<header>
    <div class="container clearfix">
        <h1 id="logo">
            TechNow
        </h1>
        <nav>
			<a href="/intro2.php">Home</a>
            <a href="">News</a>
			 <a href="">
				<?php
					if(isset($_SESSION['logdata']['username']))
{
    echo '<span style="font-size:20px;">Welcome , <u><i><b>'.$_SESSION['logdata']['username'].'</b></i></u></span>';

}
else
{
    echo 'You are not logged In';
}
				?>
			 </a>
        </nav>
    </div>
</header><!-- /header -->
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="plus_sign" ><a href="news_post.php"><i class="fa fa-plus-circle fa-5x" aria-hidden="true"></i></a></div>




<section id="entity_section" class="entity_section">
<div class="container">
<div class="row">
<div class="col-md-8">
<?php 

$m=new MongoClient();
$db=$m->project;
$collection=$db->news;
$collection1=$db->comment;
if(isset($_SESSION['logdata']['username']))
{
   // echo '<span style="font-size:20px;">Welcome , <b>'.$_SESSION['logdata']['username'].'</b></span>';

}
else
{
    echo 'You are not logged In';
}

$page  = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    $limit = 3;
    $skip  = ($page - 1) * $limit;
    $next  = ($page + 1);
    $prev  = ($page - 1);
//$cursor=$collection->find();
//$cursor = $cursor->sort(array("uploaded_on" => -1));
    $sort  = array('uploaded_on' => -1);   
    $cursor = $collection->find()->skip($skip)->limit($limit)->sort($sort);
foreach ($cursor as $document)
{
?>

<div class="entity_wrapper">
    <div class="entity_title">
        <h1><a href=<?php echo $document['category'] ?> target="_blank"><?php echo $document['heading'] ?></a>
        </h1>
    </div>
    <!-- entity_title -->

    <div class="entity_meta">
    <?php 
    $d=$document['uploaded_on'];

    ?>
        <a href="#"><?php  echo date('Y-m-d H:i:s', $d->sec);
   ?></a>, by: <a href="#"  style="color:orange;"><?php  echo $document['author']  ?></a>
    </div>
    <!-- entity_meta -->

    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-full"></i>
    </div>
  
<?php if(!empty(($document['imageid'])))
    {
?>
    <div class="entity_thumb">
        
        <?php
                $gridfs = $db->getGridFS();
                $imagetype = $document["filetype"];
                $image = $gridfs->findOne(array('_id'=>new MongoID($document['imageid'])))->getBytes();
                $im = base64_encode($image);
                
        ?>
        <img class="img-responsive" src="data:<?php echo $imagetype?>;base64,<?php echo $im ?>" width="600px" height="400px">
    </div>
    <?php 
}
    ?>

    <!-- entity_thumb -->

    <div class="entity_content">
        <p><?php  echo $document['details']?> </p>
    </div>
    <!-- entity_content -->



<form  style="float: left" class="like_bt"  action="like.php?id=<?php echo $document['_id']; ?>&uid=<?php echo $_SESSION['id'] ?>" method="post">
    <button type="submit"  class="btn btn-info btn-xs">Like (<?php echo $document['likes'] ?>)</button>
</form>
&nbsp;
  <button type="button" id="comment_bt" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal" href="comment.php?id=<?php echo $document['_id']; ?>">Comments <?php
                $id=$document['_id'];
               // echo $id;
               // $cursor=$collection1->find(array('News_id'));
                $cnt=0;
                $cursor1 = $collection1->find();
               //var_dump($cursor1->count());
               foreach ($cursor1 as $key) {
                   if($key["News_id"]==$id)
                        $cnt++;
               }
               $newdata=array('$set' =>array("total_comment" =>$cnt));
               $collection->update(array("_id"=>$id), $newdata);
               echo $cnt;
            
    ?>
  </button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div>
			<p data-dismiss="modal">Close</p>
		</div>
      </div>
    </div>
  </div>
    &nbsp;
<form  class="report_bt"  action="report.php?id=<?php echo $document['_id']; ?>&uid=<?php echo $_SESSION['id'] ?>" method="post">
    <button type="submit" class="btn btn-danger btn-xs">Report</button>
</form>


</div>
<br/>
<br/>
<?php
}
?>
<?php
$total= $cursor->count(); 
$str = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    if($page > 1){
        echo '<a id="next" href="?page=' . $prev . '">Previous</a>';
    echo $str;
        if($page * $limit < $total) {
            echo ' <a id="next" href="?page=' . $next . '">Next</a>';
        }
    } else {
        if($page * $limit < $total) {
            echo ' <a id="next" href="?page=' . $next . '">Next</a>';
        }
    }

?>

<nav aria-label="Page navigation" class="pagination_section">
    <ul class="pagination">
        <li>
            <a href="#" aria-label="Previous"> <span aria-hidden="true">&laquo;</span> </a>
        </li>
        <li>
            <a href="#" aria-label="Next" class="active"> <span aria-hidden="true">&raquo;</span> </a>
        </li>
    </ul>
</nav>
<!-- navigation -->
</div>
<!-- col-md-8 -->

<div class="col-md-4">
<div class="widget">
    <div class="">
        <h2><a href="#">Popular News</a></h2>
    </div>
    <?php
    $cursor2=$collection->find(); 
    $cursor33 = $cursor2->sort(array("likes" => -1));
    $cursor3 =$cursor33->limit(3);
foreach ($cursor3 as $document2)
{
    $gridfs = $db->getGridFS();
                $imagetype = $document2["filetype"];
				if(!empty($imagetype))
				{
					$image = $gridfs->findOne(array('_id'=>new MongoID($document2['imageid'])))->getBytes();
					$im = base64_encode($image);
				}
				else{$im="";}
     $d=$document['uploaded_on'];
    ?>

    <div class="media">
        <div class="media-left">
            <a href="#"> <img class="media-object" src="data:<?php echo $imagetype?>;base64,<?php echo $im ?>" width="80px" height="80px" alt="Not Available" ></a>
        </div>
       
        <div class="media-body">
            <h3 class="media-heading">
                <a href="single.html" target="_self"><?php echo $document2['heading']      ?></a>
            </h3> <span class="media-date"><a href="#"><?php  echo date('Y-m-d H:i:s', $d->sec); ?></a>,  by: <a href="#"><?php echo $document2['author']?></a></span>

            <div class="widget_article_social">
                <span>
                    <a href="single.html" target="_self"> <i class="fa fa-share-alt"></i><?php echo $document2['likes']; ?></a> Likes
                </span> 
                <span>
                    <a href="single.html" target="_self"><i class="fa fa-comments-o"></i><?php echo $document2['total_comment'] ?>
					</a> Comments
                </span>
            </div>
        </div>
    </div>
    <?php
}
    ?>
   
    
    
    <p class="widget_divider"><a href="#" target="_self">More News&nbsp;&raquo;</a></p>
</div>
<!-- Popular News -->







<!--<div class="widget m30">
    <div class="">
        <h2><a href="#">Editor Corner</a></h2>
    </div>
    <div class="widget_body"><img class="img-responsive left" src="" width="100" height="100" 
 width="100" height="100"                                   alt="Generic placeholder image">

        <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C
            users after installed base benefits. Dramatically visualize customer directed convergence without</p>

        <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C
            users after installed base benefits. Dramatically visualize customer directed convergence without
            revolutionary ROI.</p>
        <button class="btn pink">Read more</button>
    </div>
</div>-->
<!-- Editor News -->






</div>
<!-- col-md-4 -->

</div>
<!-- row -->

</div>
<!-- container -->

</section>
<!-- entity_section -->


</body>
</html>