<?php
    session_start();
    $info = $_SESSION['logdata'];
    echo $info['username'];
    $uid = $info['_id'];
    $data = "";
    $m = new MongoClient();
    $db = $m->project;
    $gridfs = $m->selectDB('project')->getGridFS();
    $coll = $db->debatetopic;
    $cursor = $coll->find()->sort(array('$natural'=>-1));
    $cnt = $db->discussion;
    $arrcnn = array();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!--  <link rel="stylesheet" type="text/css" href="/css/h.css">
  <link rel="stylesheet" type="text/css" href="/css/mycss.css">
-->
	<title>HOME</title>

	<script type="text/javascript">
		function logout(){
			window.location.href="/phpfiles/logout.php"
		}

function load_home(y,z) 
{
  var b = '<object type="text/html" data="/discussion.php?id='+y+'&title='+z+'" width="800px" height="600px" style="overflow:auto;"></object>';
  var a = '<object type="text/html" data="/home.php" width="800px" height="600px" style="overflow:auto;"></object>';
      document.getElementById('demo').innerHTML = b;
}

function vote(id,b,uid)
    {
      //var x =document.getElementById("first").name;
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                window.location.reload();
              }
          };
          xmlhttp.open("GET", "/phpfiles/updownvote.php?id="+id+"&button="+b+"&uid="+uid, true);
          xmlhttp.send();
    
    }

	</script>

  <style type="text/css">
    a:link {
    color: black;
    }
    a:visited {
    color: black;
    }
    <style>

    img {
    width: 100%;
    height: auto;
}

#gh {
    padding-top: 50px;
    padding-right: 500px;
    padding-bottom: 50px;
    padding-left: 80px;

}
h5 { 
   position: absolute; 
   
}
#outer
{
    width:100%;
    
}
.inner
{
    display: inline-block;
}
#text_region{
  padding-left:80px;
  padding-right:500px;

}
#publish_button{
  padding-left:80px;
}

.arial
{
  font-family: "Arial Black", Gadget, sans-serif;
}

img {
    max-width: 100%;
    height: auto;
}
​
</style>
  </style>
</head>
<body>

<nav class="navbar navbar-default navbar-fixed-top" style="background-color: #3e3e41">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="/intro2.php">HOME</a></li>
    </div>
  </div>
</nav>

<div class="modal fade" id="myprofileModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Profile</h4>
        </div>
        <div class="modal-body">
          <p><b>Name:</b>&nbsp <?php echo $info['username']; ?></p>
          <p><b>E-mail:</b>&nbsp <?php echo $info['email']; ?></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<br><br><br>


<div class="container-fluid" >
  <div class="row" >
      <center><div class="col-md-12" style="padding-bottom: 20px; border-bottom: 1px solid #ccc;" >
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal" style="background-color: #feb772">Create Debate</button>
      </div></center>
        <div class="modal fade modal-dialog modal-lg" id="myModal">
        <div class="panel panel-default">
        <div class="panel-heading">
            <span class="" style="color: #000000;"><h3>Create Debate</h3></span>
        </div>
        <div class="panel-body">
              <form class="" id="createform" action="phpfiles/createdebate.php?createdby=<?php echo $info['username']?>" method="POST" enctype="multipart/form-data">
              <div>
                  <label class="">Topic Name:</label>
                  <input class="form-control" style="" type="text" name="tname" required></p>
              </div>
              <div>
                <label class="">Label for Side A:</label>
                <input class="form-control" type="text" name="A" required>
              </div>
              <div style="padding-bottom: 5px;">
                <span align="left" style="padding-bottom: 4px;">
                  <label for="pic1" style="color: black">Image for Side A (Optional):</label>                  
                  <input style="color: black" type="file" name="pic1" id="pic1" />
              </span>
              <div>
                <label class="">Label for Side B</label>
                <input class="form-control"  type="text" name="B" required>
              </div>
              <span align="right" style="padding-top: 5px">
                  <label for="pic2" style="color: black">Image for Side B (Optional):</label>                  
                  <input style="color: black" type="file" name="pic2" id="pic2" />
              </span>
              </div>
              <div>
              <label>Enter End Date:</label><br>
              <input type="text" placeholder="date" id="date" name="date">
              <input type="text" placeholder="month" id="month" name="month">
              <input type="text" placeholder="year" id="year" name="year">
              example:19 April 2017
              </div>
              <br>
              <div class="panel-footer clearfix">
                  <div class="pull-right">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button class="btn btn-primary" type="submit">Create</button>  
                  </div>
              </div>
            </form>
        </div>    
      </div>
  </div>

  </div>
</div>

</br>
  





	
<div class="w3-container">
  <div class="w3-row ">
    <div>
    <div class="w3-twothird w3-container" style="padding-right: 100px; padding-left: px;">
      <div>
      <div class="w3-container">
        <?php
          $i=0;
            foreach ($cursor as $document) 
            {
                $id = $document['_id'];
                $upvote = "upvote";
                $downvote = "downvote";
                $up = $document['upvotearray'];
                $down = $document['downvotearray'];
                $updisable="abled";
                $downdisable="abled";



                  $totcnt = $cnt->count(array("id"=>"$id"));
                  
                  $arrcnn[$totcnt]=[$id,$document['tname']];
                
                  if($document['upvote']==0 && $document['downvote']==0)
                  {
                    $uppersent=$downpercent=0;
                  }
                  else
                  {
                    $tot=$document['upvote']+$document['downvote'];
                    $uppersent=round(($document['upvote']/$tot*100),2);
                    $downpercent=100-$uppersent;
                  }
                
                  $var = $document['year']."-".$document['month']."-".$document['date'];
                  strtotime($var);
                  time() - strtotime($var);
                  if((time()-(60*60*24)) < strtotime($var))
                  {    $intime="";     }
                  else
                  {
                    $intime="Voting is closed";
                    $updisable=$downdisable="disabled";
                  }

                if(in_array($uid, $up)){ $updisable="disabled"; $downdisable="disabled";}
                else{ /*$updisable="abled"; */}

                if(in_array($uid, $down)){ $downdisable="disabled"; $updisable="disabled";}
                else{/* $downdisable="abled"; */}

                $imageid1 = $document["imageid1"];
                $imagetype1 = $document["filetype1"];
                $imageid2 = $document["imageid2"];
                $imagetype2 = $document["filetype2"];
                if($imageid1!="")
                {
                  $image1 = $gridfs->findOne(array('_id'=>new MongoID($imageid1)))->getBytes();
                  $im1 = base64_encode($image1);
                  $image2 = $gridfs->findOne(array('_id'=>new MongoID($imageid2)))->getBytes();
                  $im2 = base64_encode($image2  );
                }
        ?>
        <div class="w3-panel w3-card">
                <div class="" style="padding-top: 10px;">
                  <div>
                    <h3 class="arial" style="font-size: 1.575em; word-wrap: break-word;font-size: 25px; "> 
              <!--      <a href="/discussion.php?id=<?php echo $document["_id"] ?>&title=<?php echo $document["tname"]?>"><span style="letter-spacing: 1px;"><?php echo $document["tname"]?></span></a> -->
                    <a data-toggle="modal" data-target="#mycomment" aria-hidden="true" onclick="load_home('<?php echo $document["_id"]; ?>','<?php echo $document["tname"]; ?>')"><?php echo $document["tname"]?></a>
                    <div style="padding-top: 10px; font-size: 20px"><small>Ends on:&nbsp<?php echo $var ?></small><small  id=""></small></div    >
                    </h3> 
                  </div>
                </div>
                

<script>
var ee = "<?php echo $document['month'];?>";
var ff="<?php echo $document['date'];?>";
var kk= "<?php echo $document['year'];?>";

var ee="21";
var ff="april";
var kk="2017";

var end = new Date(ee+"/"+ff+"/"+kk+" "+"10:1 AM");

    var _second = 1000;
    var _minute = _second * 60;
    var _hour = _minute * 60;
    var _day = _hour * 24;
    var timer;

    function showRemaining() {
        var now = new Date();
        var distance = end - now;
        if (distance < 0) {

            clearInterval(timer);
            document.getElementById('countdown').innerHTML = 'EXPIRED!';

            return;
        }
        var days = Math.floor(distance / _day);
        var hours = Math.floor((distance % _day) / _hour);
        var minutes = Math.floor((distance % _hour) / _minute);
        var seconds = Math.floor((distance % _minute) / _second);

        document.getElementById('<?php echo $document['_id'] ?>').innerHTML = days + 'days ';
        document.getElementById('<?php echo $document['_id'] ?>').innerHTML += hours + 'hrs ';
        document.getElementById('<?php echo $document['_id'] ?>').innerHTML += minutes + 'mins ';
        document.getElementById('<?php echo $document['_id'] ?>').innerHTML += seconds + 'secs';
    }

    timer = setInterval(showRemaining, 1000);
</script>


                  <span><b>Created By:&nbsp</b><i><?php if($document['createdby']==$info['username']){echo "You";} else {echo $document['createdby'];} ?></i></span>
                  
                    <?php
                      if(in_array($uid, $up))
                      {
                        echo '<br>You voted for <span style="color: #5bc0de"><b> '.$document['A'].'</b></span>';
                      }
                      else if(in_array($uid, $down))
                      {
                        echo '<br>You voted for <span style="color: #d9534f"><b>'.$document['B'].'</b></span>';
                      }
                      else
                      {
                        echo "<br>You are not participated yet";
                      }
                    ?>
                
<hr>    
              <div class="" style="padding-left: 19px; padding-top: 10px;padding-bottom: 50px;">

                <div class="debate_image"  style="float:left;margin-right:2px;" >
               <?php
                if($imageid1!="")
                {
                ?>
                  <img class="img-responsive" src="data:<?php echo $imagetype1?>;base64,<?php echo $im1 ?>" style="padding-bottom: 5px;width: 275px;height: 250px;">
                <?php
                }
                ?>
                  <button style="width:275;" class="btn btn-info" <?php echo $updisable ?> onclick="vote('<?php echo $id ?>','<?php echo $upvote ?>','<?php echo $uid ?>')"><?php echo $document['A']; ?><b>(<?php echo $document['upvote']; ?>)</b>
                  </button>
                </div>
              
                <div  style="float:left;margin-right:0px;">
                <?php
              if($imageid1!="")
              {
              ?>
                  <img  src="data:<?php echo $imagetype2?>;base64,<?php echo $im2 ?>" class="img-responsive" style="padding-bottom: 5px;width: 275px;height: 250px;">
              <?php
              }
              ?>
                  <button style="width:275; background-color: #d43f3a;" type="button" <?php echo $downdisable ?> class="btn btn-danger" onclick="vote('<?php echo $id ?>','<?php echo $downvote ?>','<?php echo $uid ?>')"><?php echo $document['B']; ?><b>(<?php echo $document['downvote']; ?>)</b>
                  </button>
                </div>
            
              </div>
              
                <p>
                <div style="padding-top: 15px;clear: left;padding-left: 19px">
                    <div style="text-align:left; ">                    
                    <button type="button" class="w3-btn w3-teal w3-round-large fa fa-comment" data-toggle="modal" data-target="#mycomment" aria-hidden="true" onclick="load_home('<?php echo $document["_id"]; ?>','<?php echo $document["tname"]; ?>')">Arguments</button>&nbsp&nbsp
                    
                    <?php
                      if($uppersent>$downpercent){$win='<b>'.$document['A'].'</b> is winning';}
                      else if($uppersent<$downpercent){$win='<b>'.$document['B'].'</b> is winning';}
                      else if($uppersent==0 && $downpercent==0){$win="No one Participated";}
                      else{$win="Debate is Tied";} 
                    ?>

                    <i><?php echo $win ?></i>&nbsp&nbsp<b><?php echo $intime; ?></b>
                    </div>
                </div>

                <div style="padding-top: 10px">
                <div class="progress">
                  <div class="progress-bar progress-bar-info" role="progressbar" style="height:18px;   width:<?php echo $uppersent?>%">
                     <?php echo $document['A']; ?>:<?php echo $uppersent;?>%
                  </div>
                  <div class="progress-bar progress-bar-danger" role="progressbar" style=" height:18px; width:<?php echo $downpercent?>%">
                    <?php echo $document['A']; ?>:<?php echo $downpercent;?>%
                  </div>
                </div>
                </div>
                </p>
        </div>




        <?php
            }
        ?>
</div>


      </div>
</div>


<div class="w3-third w3-container">
  <h2 style="font-family: monospace;">Trending</h2>
  <ul class="w3-ul" style="font-family: candara">
    <?php
      krsort($arrcnn);
      $i=0;
      foreach ($arrcnn as $a) {
        if($i++>2)
        { break;}
    ?>
    <li><a data-toggle="modal" data-target="#mycomment" onclick="load_home('<?php echo $a["0"]; ?>','<?php echo $a["1"]; ?>')"><?php echo $a['1'] ?></a></li>
    <?php
      }
    ?>
  </ul>
</div>


</div>


    </div>

<!--
    <div class="col-md-4">
    
      <div style="word-wrap: break-word; border: 10px; padding-right:20px; border-right: 1px solid #ccc;">
        <div class="panel panel-primary">
          <div class="panel-heading">Your Topics</div>
            <ul class="list-group" style="overflow-x: hidden;overflow-y: ;height: 110px;">
              <?php
                $name = $info['username']; 
                foreach($cursor as $document)
                {
                  if($document['createdby']==$name)
                 {
              ?>
              <li class="list-group-item">
              <a href="/discussion.php?id=<?php echo $document["_id"] ?>&title=<?php echo $document["tname"]?>"><b><?php echo $document['tname'] ?></b></a>
              </li>
              <?php
                  }
                }
              ?>
              <li class="list-group-item"><i><strong>No more topics created by you.......</strong></i></li>
            </ul>
        </div>
      </div>
    </div>
  -->

  </div>
  
</div>


<!--   -->  
<div id="mycomment" class="modal" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-body">
        <p id="demo"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

</body>


</html>
