

<!DOCTYPE html>
<html>
<head>
	<title>wffw</title>
</head>
<body>
<form method="POST" enctype="multipart/form-data">
    <label for="username">Username:</label>
    <input type="text" name="username" id="username" />

    <label for="pic">Please upload a profile picture:</label>
    <input type="file" name="pic" id="pic" />

    <input type="submit" />
</form>



<?php


$m = new MongoClient();
$gridfs = $m->selectDB('test')->getGridFS();

$db = $m->project;
//$coll = $db->(database_to_send);

$filetype = $_FILES["pic"]["type"];
if(empty($_FILES["pic"]["name"]))
{
	echo "yes";
}

$imageid = $gridfs->storeUpload('pic');


//$image=$gridfs->findOne(array('username'=>$_POST['username']));

$image = $gridfs->findOne(array('_id'=>new MongoID($imageid)))->getBytes();
 //header('Content-type: image/jpg;');


$im = base64_encode($image);
echo "</br>
		<img src='data:".$filetype.";base64,".$im."' width=100px height=60px />";
?>


</body>
</html>