<?php
	$m = new MongoClient();
	$d = $m->project;
	// ----------------------------------------for like and dislike
	$coll = $d->discussion;
	$mongoid = new MongoID($_GET['id']);
	$button = $_GET['button'];
	$first = array("_id"=>$mongoid);
	$second = array('$inc'=>array($button=>1));
	$coll->update($first,$second);
	$uid = $_GET['uid'];
	$second1 = array('$addToSet'=>array("agreearray"=>$uid));
	$coll->update($first,$second1);


	//-----------------------------------------for adding to user account
/*	$coll1 = $d->registration;
	$mongoid1 = $_GET['id'];
	$uid = new MongoID($_GET['uid']);
	$first1 = array("_id"=>$uid);
	if($button=="agree")
	{
		$second1 = array('$addToSet'=>array("likes"=>$mongoid1));
	}
	else
	{
		$second1 = array('$addToSet'=>array("dislikes"=>$mongoid1));
	}
	$coll1->update($first1,$second1);
*/
	$m->close();
?>
