<?php

if($_POST["fname"] && $_POST["lname"] )
{
	 $document = array(	"fname"=>$_POST["fname"],
	 					"lname"=>$_POST["lname"],
	 					"email"=>$_POST["email"],
	 					"password"=>$_POST["password"]);
	 $m = new MongoClient();
	 $db = $m->project;
	 $coll = $db->registration;
	 $coll->insert($document);
	 header("Location:/hlogin.php");
}
?>