<?php

session_start();
$info = $_SESSION['logdata'];
$username = $info['username'];

$m1 = new MongoClient();
$db1 = $m1->project;
$coll1 = $db1->discussion;
$gridfs = $db1->getGridFS();




switch ($_POST['s']) 
{
	case 'affirmative':
		$des = $_POST['des'];
		$side = "aff";
		break;
	case 'negative':
		$des = $_POST['des'];
		$side = "neg";
		break;
	default:
		echo '<script type="text/javascript">alert("write something..........");</script>';
		break;
}
$id = $_GET['id'];
$title = $_GET['title'];



$agree = 0;
$disagree =0;
$arr  = array();

if(empty($_FILES["pic"]["name"]))
{

	$insert = array("id"=>$_GET['id'],
				"sender"=>$username,
				"filetype"=>"",
				"imageid"=>"",
				"comment"=>$des,
				"side"=>$side,
				"agree"=>$agree,
				"agreearray"=>[],
				"commenton"=>[]);
}
else
{
	$filetype = $_FILES["pic"]["type"];
	$imageid = $gridfs->storeUpload('pic');
	$insert = array("id"=>$_GET['id'],
				"sender"=>$fname,
				"filetype"=>$filetype,
				"imageid"=>$imageid,
				"comment"=>$des,
				"side"=>$side,
				"agree"=>$agree,
				"agreearray"=>[],
				"commenton"=>[]);
}

if($des=="")
{
	header('Location:/discussion.php?id='.$id.'&title='.$title);
}
else
{	
	$coll1->insert($insert);
	header('Location:/discussion.php?id='.$id.'&title='.$title);
}
?>