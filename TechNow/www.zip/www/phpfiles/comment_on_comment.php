<?php
session_start();
$info = $_SESSION['logdata'];
$fname = $info['fname'];

	$m = new MongoClient();
	$d = $m->project;
	$coll = $d->discussion;
	$mongoid = new MongoID($_GET['id']);
	$oid = $_GET['oid'];
	$title = $_GET['title'];
	$comment = $_POST['comment'];
	if($comment=="")
	{
		header('Location:/discussion.php?id='.$oid.'&title='.$title);
	}
	else{
	$first = array("_id"=>$mongoid);
	$arr  = array('sender'=>$fname,'f' => $comment);
	$second = array('$addToSet'=>array("commenton"=>$arr));
	$coll->update($first,$second);
	$m->close();
	
	header('Location:/discussion.php?id='.$oid.'&title='.$title);
}
?>