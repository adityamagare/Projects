<?php 

$USERNAME=$_POST['username'];
$EMAIL=$_POST['email'];
$PASSWORD=$_POST['password'];
$C_PASSWORD=$_POST['confirm-password'];
$m = new MongoClient();
   
	
   // select a database
   $db = $m->project;

   $collection = $db->registration;
   
	
   $document = array( 
      "username" => $USERNAME, 
      "email" => $EMAIL, 
      "password" =>$PASSWORD,	
       "total_post" =>0
   );
	
   $collection->insert($document);
   header("Location: /login.php");
   

?>