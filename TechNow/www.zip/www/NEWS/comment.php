<?php 
session_start();

    $m = new MongoClient();
   //echo "Connection to database successfully"."<br>";
    
   // select a database
   $db = $m->project;
   //echo "Database mydb selected"."<br>";
   $collection = $db->news;
   $collection1 =$db->comment;

   $uid = new MongoId($_GET['id']);
   $arr = array("_id"=>$uid);
   $document = $collection->findOne($arr);

   $uid1 = $_GET['id'];
   $arr = array("News_id"=>$uid1);
   $document1 = $collection1->find($arr);

    
?>




<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="comment.css">
<link rel="stylesheet" type="text/css" href="css/news.css">
<style>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TechNow</title>
    <!-- web-fonts -->
    <link href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,500' rel='stylesheet' type='text/css'>
   <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <!-- font-awesome -->
    <link href="fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
    


</style>
</head>
<body>
<div class="modal-header">
<button type="button" class="close" ><a href="news.php">&times;</a></button>
<h4 class="modal-title"><center><h1><a href=<?php echo $document['category'] ?> target="_blank"><?php echo $document['heading'] ?></a>
        </h1></center></h4>
</div>
<div class="entity_wrapper">

     <div class="entity_meta">
	 <?php 
	 $d=$document['uploaded_on'];
	 ?>
       <center> <a href="#"><?php  echo date('Y-m-d H:i:s',$d->sec);    ?></a>, by: <a href="#"><?php  echo $document['author']  ?></a></center>
    </div>
    <?php if(!empty(($document['imageid'])))
    {
		$gridfs = $db->getGridFS();
                $imagetype = $document["filetype"];
                $image = $gridfs->findOne(array('_id'=>new MongoID($document['imageid'])))->getBytes();
                $im = base64_encode($image);
?>
    <div class="entity_thumb">
        <center><img class="img-responsive" src="data:<?php echo $imagetype?>;base64,<?php echo $im ?>" alt="feature-top" width="600px" height="400px"></center>
    </div>
    <?php
}
    ?>
     <div class="entity_content">
        <p align="center"><?php  echo $document['details']?> </p>
    </div>
</div>

<div class="container">
    <div class="row">
     <?php 
                foreach ($document1 as $doc) {
                    
               ?>
        <div class="col-sm-8">
            <div class="panel panel-white post panel-shadow">
                <div class="post-heading">
                    <div class="pull-left image">
                        <img src="http://bootdey.com/img/Content/user_1.jpg" class="img-circle avatar" alt="user profile image">
                    </div>

                    <div class="pull-left meta">
                        <div class="title h5">
                            <a href="#"><b><?php  echo $doc['comment_by']  ?></b></a>
                            made a post.
                        </div>
                       
                    </div>
                </div>
              
                <div class="post-description"> 
                    <p><?php 
                        echo $doc['Details'];
                    ?></p>
                    <div class="stats">
                        <a href="#" class="btn btn-default stat-item">
                            <i class="fa fa-thumbs-up icon"></i>2
                        </a>
                        <a href="#" class="btn btn-default stat-item">
                            <i class="fa fa-thumbs-down icon"></i>12
                        </a>
                    </div>
                </div>
                         
            </div>
        </div>
         <?php 
            }
                ?>  
        
    </div>
</div>
<div class="container">

  <h2>Post the Comment On News Here:</h2>
 
  <form action="comment_action.php?id=<?php echo $uid ?>" method="Post">
   <div class="form-group">
  <label for="comment">Comment:</label>
  <textarea style="width:800px; height:	150px;" class="form-control" name="details" rows="5" id="details1" ></textarea>
</div>
<div class="form-group">
      <button type="Submit" class="btn btn-primary" id="submit1">Post</button>
    </div>
     <input type="hidden" name="news_id" value="<?php echo $uid ?>" id="news_id1" />
  </form>

</div>


</body>
</html>