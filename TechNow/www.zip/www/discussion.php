<?php
		session_start();
		$info = $_SESSION['logdata'];
		$uid = $info['_id'];
		$id = $_GET['id'];
		$title = $_GET['title'];
		$fname = $info['username'];

		$nm = new MongoClient();
		$nd = $nm->project->debatetopic;
		$i = $nd->findOne(array("_id"=>new MongoID($id)));

		$m2 = new MongoClient();
        $db2 = $m2->project;
        $coll2 = $db2->discussion;

        $affcount = $coll2->count(array("id"=>$id));
        $negcount = $coll2->count(array("id"=>$id,"side"=>"neg"));
?>


<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="/css/mycss.css">
	<script type="text/javascript">
		
		//LIKE AND DISLIKE
		function showHint(x,b,uid)
		{
			//var x =document.getElementById("first").name;
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	           		window.location.reload();
	            }
	        };
	        xmlhttp.open("GET", "/phpfiles/likedislike.php?id=" + x + "&button=" + b + "&uid=" + uid, true);
	        xmlhttp.send();
		}


		function addComment(x)
		{
   			var c = document.getElementById(x);
   			if(c.style.display=='none'){c.style.display='block';}
   			else{c.style.display='none';}
		}

		function sendComment(x,h)
		{
			var c = document.getElementById(x);
			var c1 = document.getElementById(h)
   			if(c.style.display=='block'){c.style.display='none';}

		}
	</script>
	<title><?php echo $_GET['title']; ?></title>
</head>
<body>



<div class="container"  >

        <!-- Page Header -->
        <div class="row" >
            <div class="col-lg-12" style="padding-bottom: 1px;">
                	<h1><span class="page-header aff" style="word-wrap: break-word; letter-spacing: 1.5px; font-family: Lucida Bright"><?php echo $title ?></span>
                </h1>

                <?php
                	  $up = $i['upvotearray'];
                	  $down = $i['downvotearray'];
                      if(in_array($uid, $up))
                      {
                        echo '<br><b style="padding-top: 5px;">You voted as Agreed&nbsp</b>';
                        $s = 'affirmative';
                      }
                      else if(in_array($uid, $down))
                      {
                        echo '<br><b style="padding-top: 5px;">You voted as DisAgreed&nbsp</b>';
                        $s = 'negative';
                      }
                      else
                      {
                        echo "<br>You are not participated yet";
                      }
                    ?>
               
                <br>
                <?php
                	$tot=$i['upvote']+$i['downvote'];
                	if($tot!=0)
                	{
                		$uppersent=round(($i['upvote']/$tot*100),2);
                		$downpercent=100-$uppersent;
                	}
                	else
                	{
                		$uppersent=$downpercent=0;
                	}
                ?>
                <div class="progress">
    				<div class="progress-bar progress-bar-success" role="progressbar" style="width:<?php echo $uppersent?>%">
    				  Supporting:<?php echo $uppersent;?>%
    				</div>
    				<div class="progress-bar progress-bar-warning" role="progressbar" style="width:<?php echo $downpercent?>%">
      					Not Supporting:<?php echo $downpercent;?>%
    				</div>
				</div>
        	</div>
</div>
</div>

<div class="container" >

        <div class="row">
            <div class="col-md-12 portfolio-item" style="padding-right: 10px;padding-left: 80px ">
               	<form class="form-horizontal" action=/phpfiles/addComment.php?id=<?php echo $id; ?>&title=<?php echo $title; ?> method="POST" enctype="multipart/form-data">
					<div class="form-group">
						<div class="col-sm-10">
        					<textarea class="form-control" cols="50" rows="3" name="des" placeholder="What is in your mind" required></textarea>
        					<label for="pic" style="color: black">Image to Uplaod:</label>
    						<input style="color: black" class="w3-btn w3-round-large" type="file" name="pic" id="pic" />
        				</div>
        				<div class="col-sm-2">
        					<button type="submit" class="btn btn-primary" name="s" value="<?php echo $s; ?>">Go on!</button>
      					</div>
    				</div>
				</form>
            </div>
        </div>
</div>



<?php
		
      

        $gridfs = $m2->selectDB('project')->getGridFS();

     	$arr = array("id"=>$id);
        $cursor1 = $coll2->find($arr)->sort(array('$natural'=>-1));
      //  $cursor2 = $coll2->find($d2)->sort(array('$natural'=>-1));

?>
<div class="container">
    <div class="row" >
        
        <div class="col-md-12 portfolio-item " style="padding-right: 10px;padding-left: 10px;	">
        <div class="w3-container">
  

			<div class="w3-container">
	    		
<?php
		foreach ($cursor1 as $document1) 
		{

			$f=$document1["_id"];
			$a = "agree";
			$da = "disagree";
			$agreearray1 = $document1['agreearray'];
		
			if(in_array($uid, $agreearray1)){ $likedisable="disabled";}
			else{ $likedisable="abled";}

				$imageid1 = $document1["imageid"];
				$imagetype1 = $document1["filetype"];
				if($imageid1!="")
				{
					$image1 = $gridfs->findOne(array('_id'=>new MongoID($imageid1)))->getBytes();
					$im1 = base64_encode($image1);
				}
?>

	<div class="w3-panel w3-card-4">
		<div class="" >
			<b><p style="padding-top: 20px">Said By-&nbsp<i><?php echo $document1["sender"] ?></i></p></b>
			<?php
				if($document1['side']=="aff")
					echo '<h3 style="font-family: Tahoma;color: green;padding-left: 30px";letter-spacing: 2px>'.$document1["comment"].'</h3>';
				else
					echo '<h3 style="font-family: Tahoma;color: red;padding-left: 30px; letter-spacing: 2px">'.$document1["comment"].'</h3>';
			?>
				
			<?php
				if($imageid1!="")
				{
			?>
				<div>
					<img src="data:<?php echo $imagetype1?>;base64,<?php echo $im1 ?>" width=50% height=50% />
				</div>
			<?php
				}
			?>
				<p>
					<button type="button" data-toggle="collapse" data-target="#<?php echo $f ?>" class="btn btn-link">Comment</button> 
					<?php echo $document1['agree'] ?>
					<button type="button" <?php echo $likedisable ?> onClick= 'showHint("<?php echo $f ?>","<?php echo $a ?>","<?php echo $uid ?>")' class="btn btn-info btn-xs">Like</button>
				</p>

			<div id="<?php echo $f ?>" class="collapse" >
				<form class="form-group" action=/phpfiles/comment_on_comment.php?id=<?php echo $f ?>&oid=<?php echo $id ?>&title=<?php echo $title ?> method="POST" id="<?php echo $f ?>">
					<input type="text" name="comment" class="form-control" required>
					<button class="btn" onclick='sendComment(" <?php echo $f ?>","<?php echo $f ?>")'>Post</button>
				</form>
				<p>
				<?php 
					foreach ($document1['commenton'] as $k)
					{
				?>
				<?php echo $k['f'] ?>
					<span class="text-center"></span></br>
				<?php					
					}
				?>
				</p>
			</div>
	    </div>
	</div>
	    
<?php	       		
		}
?>
</div></div></div></div>
	
</body>
</html>