<?php
		session_start();
		$info = $_SESSION['logdata'];
		echo '<h1>'.$info['email'].'</h1>';
		$uid = $info['_id'];
		

		$mongoid = new MongoID($uid);
		$doc = array("_id"=>$mongoid);
		$m = new MongoClient();
		$db = $m->project;
		$coll = $db->registration;
		$buttoninfo = $coll->findOne($doc);

		$w = $buttoninfo['likes'];	
		$x = $buttoninfo['dislikes'];
?>


<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-camo.css">
	  <link rel="stylesheet" href="/lib/w3-colors-signal.css">
	<script type="text/javascript">
		
		//LIKE AND DISLIKE
		function showHint(x,b,uid)
		{
			//var x =document.getElementById("first").name;
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
	            if (this.readyState == 4 && this.status == 200) {
	           		window.location.reload();
	            }
	        };
	        xmlhttp.open("GET", "/phpfiles/likedislike.php?id=" + x + "&button=" + b + "&uid=" + uid, true);
	        xmlhttp.send();
		}

		function back(){window.location.href = '/debate.php';}

		function addComment(x)
		{
   			var c = document.getElementById(x);
   			if(c.style.display=='none'){c.style.display='block';}
   			else{c.style.display='none';}
		}

		function sendComment(x,h)
		{
			var c = document.getElementById(x);
			var c1 = document.getElementById(h)
   			if(c.style.display=='block'){c.style.display='none';}

		}
	</script>
	<title><?php echo $_GET['title']; ?></title>
</head>
<body>

	<button onclick="back()">BaCk</button>

	<?php
	$id = $_GET['id'];
	$title = $_GET['title'];

	
	echo '<table width=100% ><tr>
	<td><span align="center">
	<form action=/phpfiles/addComment.php?id='.$id.'&title='.$title.' method="POST">
		<p>
			<input type="text" name="aff" />
			<input type="submit" name="s" value="affirmative" />
		</p>
	</form>
	</span></td>
	<td><span align="center">
	<form action=/phpfiles/addComment.php?id='.$id.'&title='.$title.' method="POST">		
		<p>
			<input type="text" name="neg" />
			<input type="submit" name="s" value="negative" />
		</p>
	</form>
	</span></td>
	</tr></table>
	';

		
		
        $m2 = new MongoClient();
        $db2 = $m2->project;
        $coll2 = $db2->discussion;

        $d1 = array("id"=>$_GET['id'],"side"=>"aff");
        $d2 = array("id"=>$_GET['id'],"side"=>"neg");
        $cursor1 = $coll2->find($d1);
        $cursor2 = $coll2->find($d2);

		$data = '<table border=5 style="width:100%"><tr align="center"><td>AFFIRMATIVE</td><td>NEGATIVE</td></tr><tr><td style="width: 50%;"><table border=1 style="width:100%">';
		foreach ($cursor1 as $document1) 
		{
			$f=$document1["_id"];
			$a = "agree";
			$da = "disagree";
			$data .= "<tr>";
			$data .= '<td>'.$document1["comment"];

			$data .= '<div>';
			foreach ($document1['commenton'] as $k) {
						$data .= $k['f'].'</br>';
					}
			$data .= '</div>';

			$data .= '<div align="right">';
			$data .= '<button onclick=addComment("'.$f.'") >Comment</button>
						<form action=/phpfiles/comment_on_comment.php?id='.$f.'&oid='.$id.'&title='.$title.' method="POST" id="'.$f.'" style="display: none">
							<input type="text" name="comment" >
							<button onclick=sendComment("'.$f.'","'.$f.'")>post</button>
						</form></div></td>';
			
			
			if(in_array($f, $w)){ $likedisable="disabled";}
			else{ $likedisable="abled";}

			if(in_array($f, $x)){ $dlikedisabled="disabled";}
			else{ $dlikedisabled="abled";}

			$data .='<td>'.$document1['agree'].'<button '.$likedisable.' onClick= showHint("' . $f.'","'.$a.'","'.$uid.'");>Like</button></td>';
			$data .='<td>'.$document1['disagree'].'<button '.$dlikedisabled.' onClick= showHint("' . $f.'","'.$da.'","'.$uid.'");>Dislike</button></td>';
			$data .= "</tr>";
		}
		$data .= '</table></td><td style="width: 50%;"><table border=1 style="width:100%;">';
		foreach ($cursor2 as $document2)
		{
			$f=$document2["_id"];
			$a = "agree";
			$da = "disagree";
			$data .= "<tr>";
			$data .= '<td>'.$document2["comment"];

			$data .= '<div>';
			foreach ($document2['commenton'] as $k) {
						$data .= $k['f'].'</br>';
					}
			$data .= '</div>';

			$data .= '<div align="right">';
			$data .= '<button onclick=addComment("'.$f.'") >Comment</button>
						<form action=/phpfiles/comment_on_comment.php?id='.$f.'&oid='.$id.'&title='.$title.' method="POST" id="'.$f.'" style="display: none">
							<input type="text" name="comment" >
							<button onclick=sendComment("'.$f.'","'.$f.'")>post</button>
						</form></div></td>';


			if(in_array($f, $w)){ $likedisable="disabled";}
			else{ $likedisable="abled";}

			if(in_array($f, $x)){ $dlikedisabled="disabled";}
			else{ $dlikedisabled="abled";}



			$data .='<td>'.$document2['agree'].'<button '.$likedisable.' onClick= showHint("' . $f.'","'.$a.'","'.$uid.'");>Like</button></td>';
			$data .='<td>'.$document2['disagree'].'<button '.$dlikedisabled.' onClick= showHint("' . $f.'","'.$da.'","'.$uid.'");>Dislike</button></td>';
			$data .= "</tr>";
		}
		$data .= "</table></td></tr></table>";

		echo $data;

		
	
	
	?>	

	
</body>
</html>