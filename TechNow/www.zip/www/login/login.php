<?php
session_start();
echo "wew".$_SESSION['counter'];
if( isset( $_SESSION['counter'] ) )
{
	echo "wew".$_SESSION['counter'];
$_SESSION['counter'] += 1;
}
else
{
$_SESSION['counter'] = 1;
}
$msg = "You have visited this page ". $_SESSION['counter'];
$msg .= "in this session.";
session_destroy();
/*
$a = array("f"=>"e");
if(empty($a)){
      echo "yes";
}
else{
      echo "no";
}*/

?>
<html>
<head>
<title>Setting up a PHP session</title>
</head>
<body>
<?php echo ( $msg );?> 
</body>
</html>