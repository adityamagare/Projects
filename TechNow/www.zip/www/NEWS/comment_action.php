<?php 
session_start();
$details=$_POST['details'];
$new_id=$_GET['id'];

$m = new MongoClient();
   //echo "Connection to database successfully"."<br>";
	
   // select a database
   $db = $m->project;
   //echo "Database mydb selected"."<br>";
   $collection = $db->comment;
   //echo "Collection selected succsessfully"."<br>"
   //$dt = new DateTime(date('Y-m-d'), new DateTimeZone('UTC'));
   //$ts = $dt->getTimestamp();
   //$today = new MongoDate($ts);
   $document = array(
      "Details" =>$details,
      "News_id"=>$new_id,
      "comment_by"=>$_SESSION['user']
   );

  
	
   $collection ->insert($document);
   //echo "Document inserted successfully";
   //header("Location:comment.php?id=".$new_id);
header("Location:news.php");
?>