<html>
<head><title>Registration</title></head>
<body>
	<form action="phpfiles/signup.php" method="POST">
		First name:<input type="text" name="fname"/>
		Last name:<input type="text" name="lname"/>
		E-mail:<input type="text" name="email"/>
		Sex:<select name="sex">
				<option value="select"></option>
				<option value="male">Male</option>
				<option value="female">Female</option>
			</select>
		Date of Birth:<input type="text" name="dob" placeholder="01/01/2001">
		<input type="submit" name="Sign Up">
	</form>
</body>
</html>
