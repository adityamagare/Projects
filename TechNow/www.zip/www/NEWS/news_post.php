<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Post the Tech News Now:</h2>
  <p>An exclusive website for Tech News</p>
  <form action="news_action.php" method="Post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="usr">News-Heading:</label>
      <input type="text" name="heading" class="form-control" id="heading1">
    </div>
    <div class="form-group">
      <label for="pwd">News-Link:</label>
      <input type="text" name="category" class="form-control" id="category1">
    </div>
    <div class="form-group">
      <label for="pic">Upload Picture</label>
      <input  type="file" name="pic" id="pic"/>
    </div>
    <div class="form-group">
  <label for="comment">Details:</label>
  <textarea class="form-control" name="details" rows="5" id="details1"></textarea>
</div>
<div class="form-group">
      <button type="Submit" class="btn btn-primary" id="submit1">Submit</button>
    </div>
  </form>
</div>

</body>
</html>
