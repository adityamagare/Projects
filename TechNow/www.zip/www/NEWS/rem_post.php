<?php
session_start();
$m=new MongoClient();
 $db = $m->mydb;
 $collection = $db->news;
 $news_id = new MongoId($_GET['id']);
 $arr = array("_id"=>$news_id);
 $collection->remove($arr);

 header("Location:admin.php");

?>