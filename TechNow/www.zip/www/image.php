<?php



$filepath = $argv[1];


$m = new MongoClient();
$grid = $m->selectDB('test')->getGridFS();



# We are going to search for the filepath passed in as first argument
$searchParams = array("username" => "as");


# Alternatively use findOne($searchParams) if you
# expect there to only be one file with the provided name.
$files = $grid->find($searchParams);

while (($file = $files->getNext()) != null)
{
    # Use a random string in case there is a file with the same name
    # in the current directory.
    $randString = substr(str_shuffle(MD5(microtime())), 0, 10);
    $outputFilepath = __DIR__ . '/' . $randString . "_" . basename($file->getFilename());
    echo $randString."</br>".basename($file->getFilename())."</br></br>";
   // $file->write($outputFilepath);
   // print "Retrieved: " . $outputFilepath . PHP_EOL;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>
