 <?php
    $m=new MongoClient();
$db=$m->mydb;
$collection=$db->news;

    $page  = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    $limit = 2;
    $skip  = ($page - 1) * $limit;
    $next  = ($page + 1);
    $prev  = ($page - 1);
    $sort  = array('uploaded_on' => -1);   
    $cursor = $collection->find()->skip($skip)->limit($limit)->sort($sort);
    foreach ($cursor as $r) {
        echo $r['heading']."<br>";
    } 
$total= $cursor->count(); 
    if($page > 1){
        echo '<a href="?page=' . $prev . '">Previous</a>';
        if($page * $limit < $total) {
            echo ' <a href="?page=' . $next . '">Next</a>';
        }
    } else {
        if($page * $limit < $total) {
            echo ' <a href="?page=' . $next . '">Next</a>';
        }
    }

    //$mongodb->close();
    ?>