<?php
	session_start();
	$info = $_SESSION['logdata'];

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="/css/h.css">
	<title>HOME</title>
	<script type="text/javascript">
		function logout(){
			window.location.href="/phpfiles/logout.php"
		}
	</script>
</head>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50" style="background-color:#d9d9d9;"  >
<nav class="navbar navbar-default navbar-fixed-top" >
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#myPage">HOME</a></li>
        <li><a href="#about">About Us</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Options
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Profile</a></li>
            <li><a href="/phpfiles/logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<br/>
<br/>
<br/>
<br/>
<div id="myPage" class="bg-1" style="background-color: #026454">
  <div class="container" >
    
    <div class="row text-center">
      <div class="col-sm-5">
        <div class="thumbnail" style="background-color: #233;">
          <img src="/img/debate.jpg" alt="Paris" width="400" height="300">
          <a href="d.php"><p><h2 style="color: white;font-family: Calisto MT">Debate</h2></p></a>
        </div>
      </div>
      <div class="col-sm-2"></div>
      <div class="col-sm-5">
        <div class="thumbnail" style="background-color: #233">
          <img src="/img/news_logo.gif" alt="New York" width="400" height="300">
          <a href="/news/news.php"><p><h2 style="color: white;font-family: Calisto MT">News</h2></p></a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -->
<br><br><br>


<div id="myPage" class="bg-1" style="background-color: #18b495">
<div id="about" class="container">
  <h3 class="text-center">Contact Us</h3>

  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Praful</a></li>
    <li><a data-toggle="tab" href="#menu1">Aditya</a></li>
    <li><a data-toggle="tab" href="#menu2">Rohan</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h2>Praful Jadhav</h2>
      <p></p>
    </div>
    <div id="menu1" class="tab-pane">
      <h2>Aditya Magare</h2>
      <p></p>
    </div>
    <div id="menu2" class="tab-pane fade">
      <h2>Rohan Khul</h2>
      <p></p>
    </div>
  </div>
</div>
</div>

  


<script>
$(document).ready(function(){
  // Initialize Tooltip
  $('[data-toggle="tooltip"]').tooltip(); 
  
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {

      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
})
</script>





</body>
</html>
