<?php
		session_start();
		$info = $_SESSION['logdata'];
		$data = "";
		$m = new MongoClient();
		$db = $m->project;
		$coll = $db->debatetopic;
		$cursor = $coll->find();
		
?>
<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	  <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-camo.css">
	  <link rel="stylesheet" href="/lib/w3-colors-signal.css">
	  <title>Debate</title>

</head>
<body>

<header class="w3-container w3-camo-olive">
  <div class=" w3-padding-large">
      <span class="w3-xlarge">Debate Time</span>
      <span class="w3-right w3-padding w3-hide-small"></span>
    </div>
</header>
<br>
<div class="w3-cell-row">
  
  <div class="w3-container w3-cell w3-panel w3-border-right" style="width:35%">
	 <div class="w3-container w3-card" style="background-color: #ffffcc;">
		 <p class="w3-container w3-panel w3-xlarge">
		 	  <span class="w3-text-blue " style="color: #0000ff;">Create Debate</span>
	     </p>

		<form class="w3-container" id="createform" action="phpfiles/createdebate.php" method="POST">
		  <p>
		  <label class="">Topic Name:</label>
		  <input class="w3-input w3-border-bottom " style="background-color: #ffffcc;" type="text" name="tname"></p>
		  <p>
		  <label class="w3-text-cyan">Description:</label>
		  <textarea class="w3-input" style="background-color: #ffffcc;"  cols="30" rows="7" name="description" placeholder="writes something here"></textarea></p>
		  <div class=" w3-padding-16">
	        <button class="w3-button w3-white w3-border w3-border-teal w3-round-large" type="submit">Create</button>
	      </div>
		</form>
	</div>
  </div>

<div class="w3-container  w3-cell" >

    <?php

		foreach ($cursor as $document) 
		{
			$data .= '<div class="w3-panel w3-khaki w3-card-4"><article>';
			$data .= "<a href='/discussion.php?id=".$document["_id"]."&title=".$document["tname"]."'><h2>".$document["tname"]."</h2></a>";
			$data .= '<p>'.$document["description"].'<div style="text-align:right;"><button>I Disagree</button>&nbsp<button>I Agree</button></div></p></article></div>';

		}
		echo $data;
	?>
</div>



</body>
</html>